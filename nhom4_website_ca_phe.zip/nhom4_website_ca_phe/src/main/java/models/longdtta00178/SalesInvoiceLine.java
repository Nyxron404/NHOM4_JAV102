package models.longdtta00178;

import java.math.BigDecimal;

/**
 * Chi tiết hóa đơn bán
 * <p>Bảng: sales_invoice_lines</p>
 */
public class SalesInvoiceLine {

    public static final String TABLE = "sales_invoice_lines";
    public static final String[] PRIMARY_KEY = {"sales_line_id"};

    /** sales_line_id | BIGINT | PK | tự tăng */
    private Long salesLineId;
    /** sales_invoice_id | BIGINT | FK → sales_invoices.sales_invoice_id | NOT NULL */
    private Long salesInvoiceId;
    /** package_id | INT | FK → packages.package_id | NOT NULL */
    private Integer packageId;
    /** quantity | INT | NOT NULL */
    private Integer quantity;
    /** unit_price | NUMERIC(14,0) | NOT NULL */
    private BigDecimal unitPrice;
        // ---- Thông tin hiển thị (tính từ JOIN, không lưu DB) ----
    private String sku;
    private String variantName;
    private Integer weightG;
    private Boolean wholeBean;
    /** Số lượng tối đa được bán = tồn các lô còn hạn của gói */
    private Integer maxQty;

    public SalesInvoiceLine() {}

    public Long getSalesLineId() { return salesLineId; }
    public void setSalesLineId(Long salesLineId) { this.salesLineId = salesLineId; }
    public Long getSalesInvoiceId() { return salesInvoiceId; }
    public void setSalesInvoiceId(Long salesInvoiceId) { this.salesInvoiceId = salesInvoiceId; }
    public Integer getPackageId() { return packageId; }
    public void setPackageId(Integer packageId) { this.packageId = packageId; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
        public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public String getVariantName() { return variantName; }
    public void setVariantName(String variantName) { this.variantName = variantName; }
    public Integer getWeightG() { return weightG; }
    public void setWeightG(Integer weightG) { this.weightG = weightG; }
    public Boolean getWholeBean() { return wholeBean; }
    public void setWholeBean(Boolean wholeBean) { this.wholeBean = wholeBean; }
    public Integer getMaxQty() { return maxQty; }
    public void setMaxQty(Integer maxQty) { this.maxQty = maxQty; }
    /** Thành tiền = số lượng * đơn giá */
    public BigDecimal getLineAmount() {
        return unitPrice == null || quantity == null ? BigDecimal.ZERO : unitPrice.multiply(BigDecimal.valueOf(quantity));
    }
    @Override
    public String toString() {
        return "SalesInvoiceLine{" + "salesLineId=" + salesLineId + ", salesInvoiceId=" + salesInvoiceId + ", packageId=" + packageId + ", quantity=" + quantity + ", unitPrice=" + unitPrice + "}";
    }
}
